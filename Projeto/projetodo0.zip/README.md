# global opportuna
